# sensorApp/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'sensorApp'

urlpatterns = [
    # ── Sensor dashboard (main page for live hardware view) ───────────────────
    path('sensor/', views.dashboard, name='sensorDashboard'),

    # ── Auth (standalone sensorApp auth – optional, main auth is via myapp) ───
    path('sensor/signup/',  views.signup_view,      name='signup'),
    path('sensor/login/',   views.SensorLoginView.as_view(), name='login'),
    path('sensor/logout/',  views.logout_view,      name='logout'),

    # ── Profile ───────────────────────────────────────────────────────────────
    path('sensor/profile/',      views.profile_view,      name='profile'),
    path('sensor/edit-profile/', views.edit_profile_view, name='edit_profile'),

    # ── Other pages ───────────────────────────────────────────────────────────
    path('sensor/about/',          views.about_view,         name='about'),
    path('sensor/feedback/',       views.feedback_view,       name='feedback'),
    path('sensor/feedback-thanks/', views.feedback_thanks_view, name='feedback_thanks'),
    path('sensor/alerts/',         views.alert_history,       name='sensor_alert_history'),

    # ── Password change ───────────────────────────────────────────────────────
    path('sensor/change-password/',
         auth_views.PasswordChangeView.as_view(
             template_name='registration/change_password.html',
             success_url='/sensor/change-password/done/'
         ), name='change_password'),
    path('sensor/change-password/done/',
         auth_views.PasswordChangeDoneView.as_view(
             template_name='registration/change_password_done.html'
         ), name='password_change_done'),

    # ── Password reset ────────────────────────────────────────────────────────
    path('sensor/password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='registration/password_reset.html',
             success_url='/sensor/password-reset/done/'
         ), name='password_reset'),
    path('sensor/password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='registration/password_reset_done.html'
         ), name='password_reset_done'),
    path('sensor/reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='registration/password_reset_confirm.html',
             success_url='/sensor/reset/done/'
         ), name='password_reset_confirm'),
    path('sensor/reset/done/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='registration/password_reset_complete.html'
         ), name='password_reset_complete'),

    # ── JSON APIs (called by sensor dashboard JS) ─────────────────────────────
    path('api/sensor/',  views.sensor_api,  name='sensorApi'),
    path('api/latest/',  views.latest_data, name='sensor_latest_data'),
    path('api/chart/',   views.chart_data,  name='sensor_chart_data'),
    path('api/weather/', views.weather_api, name='weather_api'),
]
