# sensorApp/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from myapp.models import CustomUser

from .models import Feedback


class SignupForm(UserCreationForm):
    name  = forms.CharField(label='Full Name', max_length=100)
    email = forms.EmailField(required=True)

    class Meta:
        model  = CustomUser
        fields = ['name', 'username', 'email', 'password1', 'password2']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Remove password validator messages
        self.fields['password1'].help_text = ''
        self.fields['password2'].help_text = ''
        
        # Add placeholders for better UX
        self.fields['name'].widget.attrs.update({'placeholder': 'Full Name'})
        self.fields['username'].widget.attrs.update({'placeholder': 'Username'})
        self.fields['email'].widget.attrs.update({'placeholder': 'Email Address'})
        self.fields['password1'].widget.attrs.update({'placeholder': 'Password'})
        self.fields['password2'].widget.attrs.update({'placeholder': 'Confirm Password'})


class FeedbackForm(forms.ModelForm):
    class Meta:
        model  = Feedback
        fields = ['name', 'email', 'message']
        widgets = {
            'name':    forms.TextInput(attrs={'placeholder': 'Enter your full name'}),
            'email':   forms.EmailInput(attrs={'placeholder': 'Enter your email'}),
            'message': forms.Textarea(attrs={
                'placeholder': 'Write your feedback here...',
                'rows': 5,
            }),
        }
