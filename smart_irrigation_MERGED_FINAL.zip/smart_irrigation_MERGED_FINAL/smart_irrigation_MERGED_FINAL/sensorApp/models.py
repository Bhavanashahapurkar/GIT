# sensorApp/models.py

import requests

from django.db import models
from django.conf import settings


# ═════════════════════════════════════════════════════════════
# SENSOR DATA MODEL
# ═════════════════════════════════════════════════════════════

class SensorData(models.Model):
    """
    Stores real-time sensor readings
    from ESP32 / ThingSpeak.
    """

    # Water tank distance
    distance = models.FloatField(
        help_text='Ultrasonic sensor distance in cm'
    )

    # Soil moisture
    soil = models.FloatField(
        help_text='Soil moisture sensor value'
    )

    # Temperature
    temperature = models.FloatField(
        null=True,
        blank=True
    )

    # Humidity
    humidity = models.FloatField(
        null=True,
        blank=True
    )

    # Date & time automatically stored
    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return (
            f"{self.created_at:%Y-%m-%d %H:%M:%S} | "
            f"Soil={self.soil} | "
            f"Distance={self.distance}"
        )

    # ─────────────────────────────────────────────────────────
    # Fetch latest data from ThingSpeak
    # ─────────────────────────────────────────────────────────

    @staticmethod
    def fetch_from_thingspeak():

        channel_id = getattr(
            settings,
            'THINGSPEAK_CHANNEL_ID',
            '3377240'
        )

        api_key = getattr(
            settings,
            'THINGSPEAK_API_KEY',
            'RZJFAUFNYENLCFC3'
        )

        url = (
            f"https://api.thingspeak.com/channels/"
            f"{channel_id}/feeds.json"
        )

        try:

            response = requests.get(
                url,
                params={
                    'api_key': api_key,
                    'results': 1
                },
                timeout=8
            )

            if response.status_code == 200:

                data = response.json()

                if data.get('feeds'):

                    latest = data['feeds'][0]

                    return SensorData.objects.create(

                        distance=float(
                            latest.get('field1') or 0
                        ),

                        soil=float(
                            latest.get('field2') or 0
                        ),

                        temperature=float(
                            latest.get('field3') or 0
                        ),

                        humidity=float(
                            latest.get('field4') or 0
                        ),
                    )

        except Exception as e:

            print("ThingSpeak Fetch Error:", e)

        return None


# ═════════════════════════════════════════════════════════════
# ALERT MODEL
# ═════════════════════════════════════════════════════════════

class Alert(models.Model):

    distance = models.FloatField()

    soil = models.FloatField()

    message = models.TextField()

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return (
            f"Alert | "
            f"{self.created_at:%Y-%m-%d %H:%M:%S}"
        )


# ═════════════════════════════════════════════════════════════
# FEEDBACK MODEL
# ═════════════════════════════════════════════════════════════

class Feedback(models.Model):

    name = models.CharField(
        max_length=100
    )

    email = models.EmailField()

    message = models.TextField()

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    def __str__(self):

        return self.name