from django.contrib import admin
from .models import SensorData, Alert, Feedback


@admin.register(SensorData)
class SensorDataAdmin(admin.ModelAdmin):
    list_display  = ('created_at', 'distance', 'soil', 'temperature', 'humidity')
    ordering      = ['-created_at']
    list_filter   = ('created_at',)


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display  = ('created_at', 'soil', 'distance', 'message')
    ordering      = ['-created_at']


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display  = ('name', 'email', 'created_at')
    search_fields = ('name', 'email')
    ordering      = ['-created_at']
