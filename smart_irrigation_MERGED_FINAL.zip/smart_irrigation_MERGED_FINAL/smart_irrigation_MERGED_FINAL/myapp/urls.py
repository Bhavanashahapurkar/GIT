# myapp/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.conf.urls.static import static

from .views import (
    base, signup_view, CustomLoginView,
    profile_view, edit_profile,
    about,
    user_list_view, chat_view_by_id,
    feedback_view, view_feedbacks,
)
from modelapp.views import dashboard

urlpatterns = [
    # Landing
    path('', base, name='base'),
    path('about/', about, name='about'),

    # Auth
    path('signup/', signup_view, name='signup'),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # Password change
    path('password/', auth_views.PasswordChangeView.as_view(
        template_name='registration/change_password.html',
        success_url='/dashboard/'
    ), name='change_password'),

    # Password reset
    path('reset-password/', auth_views.PasswordResetView.as_view(
        template_name='registration/password_reset.html'
    ), name='password_reset'),
    path('reset-password/done/', auth_views.PasswordResetDoneView.as_view(
        template_name='registration/password_reset_done.html'
    ), name='password_reset_done'),
    path('reset-password-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
        template_name='registration/password_reset_confirm.html'
    ), name='password_reset_confirm'),
    path('reset-password-complete/', auth_views.PasswordResetCompleteView.as_view(
        template_name='registration/password_reset_complete.html'
    ), name='password_reset_complete'),

    # Profile
    path('profile/', login_required(profile_view), name='profile'),
    path('profile/edit/', edit_profile, name='edit_profile'),

    # Dashboard (served from modelapp)
    path('dashboard/', dashboard, name='dashboard'),

    # Chat
    path('messages/', user_list_view, name='user_list'),
    path('messages/<int:user_id>/', chat_view_by_id, name='chat'),

    # Feedback
    path('feedback/', feedback_view, name='feedback'),
    path('feedbacks/', view_feedbacks, name='view_feedbacks'),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
