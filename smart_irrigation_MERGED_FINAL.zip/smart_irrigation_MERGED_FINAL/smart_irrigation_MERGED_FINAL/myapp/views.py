# myapp/views.py
import logging

from django.contrib.auth import login, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.contrib import messages
from django.core.mail import send_mail
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings

from .forms import CustomUserCreationForm, ProfileForm, FeedbackForm
from .models import CustomUser, Message, Feedback
from modelapp.views import dashboard  # noqa – imported so urls can reference it

logger = logging.getLogger(__name__)


# ── Landing page ──────────────────────────────────────────────────────────────
def base(request):
    return render(request, 'base.html')


# ── Auth ──────────────────────────────────────────────────────────────────────
def signup_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('dashboard')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})


class CustomLoginView(LoginView):
    template_name = 'registration/login.html'

    def get_success_url(self):
        user = self.request.user
        if user.is_superuser or user.is_staff:
            return '/admin/'
        return super().get_success_url()


# ── Profile ───────────────────────────────────────────────────────────────────
@login_required
def profile_view(request):
    return render(request, 'account/profile.html', {'user': request.user})


@login_required
def edit_profile(request):
    user = request.user
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('profile')
    else:
        form = ProfileForm(instance=user)
    return render(request, 'account/edit_profile.html', {'form': form})


# ── About ─────────────────────────────────────────────────────────────────────
def about(request):
    return render(request, 'about/about.html')


# ── Chat / Messages ───────────────────────────────────────────────────────────
@login_required
def user_list_view(request):
    users = get_user_model().objects.exclude(id=request.user.id)
    return render(request, 'users/user_list.html', {'users': users})


@login_required
def chat_view_by_id(request, user_id):
    other_user = get_object_or_404(CustomUser, id=user_id)
    msgs = Message.objects.filter(
        Q(sender=request.user, receiver=other_user) |
        Q(sender=other_user, receiver=request.user)
    ).order_by('timestamp')

    if request.method == 'POST':
        text = request.POST.get('text', '')
        image = request.FILES.get('image')
        Message.objects.create(
            sender=request.user,
            receiver=other_user,
            text=text,
            image=image
        )
        return redirect('chat', user_id=other_user.id)

    return render(request, 'users/chat.html', {
        'messages': msgs,
        'receiver': other_user,
    })


# ── Feedback ──────────────────────────────────────────────────────────────────
@login_required
def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.user = request.user
            feedback.save()

            # Email admins
            admin_emails = [addr for _, addr in getattr(settings, 'ADMINS', []) if addr]
            if not admin_emails:
                admin_emails = [getattr(settings, 'DEFAULT_FROM_EMAIL', '')]
            admin_emails = [e for e in admin_emails if e]

            if admin_emails:
                try:
                    send_mail(
                        subject=f"New Feedback from {request.user.username}",
                        message=(
                            f"User: {request.user.get_full_name() or request.user.username}\n"
                            f"Email: {request.user.email}\n\n"
                            f"---- Feedback ----\n"
                            f"{form.cleaned_data.get('message', '')}"
                        ),
                        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', None),
                        recipient_list=admin_emails,
                        fail_silently=True,
                    )
                except Exception as exc:
                    logger.exception("Feedback email failed: %s", exc)

            return render(request, 'feedback/feedback_thanks.html')
    else:
        form = FeedbackForm()
    return render(request, 'feedback/feedback.html', {'form': form})


@login_required
def view_feedbacks(request):
    if request.user.is_superuser:
        feedbacks = Feedback.objects.all().order_by('-created_at')
        return render(request, 'feedback/view_feedbacks.html', {'feedbacks': feedbacks})
    return redirect('dashboard')
