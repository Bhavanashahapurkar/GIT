# modelapp/views.py
import os
import joblib

from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.shortcuts import render

from .models import IrrigationPrediction

# ── Load ML models at startup ─────────────────────────────────────────────────
_MODEL_DIR = os.path.join(settings.BASE_DIR, 'modelapp', 'models')

model    = joblib.load(os.path.join(_MODEL_DIR, 'model.pkl'))
le_soil  = joblib.load(os.path.join(_MODEL_DIR, 'le_soil.pkl'))
le_crop  = joblib.load(os.path.join(_MODEL_DIR, 'le_crop.pkl'))
le_water = joblib.load(os.path.join(_MODEL_DIR, 'le_water.pkl'))
le_output = joblib.load(os.path.join(_MODEL_DIR, 'le_output.pkl'))


# ── Dashboard ─────────────────────────────────────────────────────────────────
@login_required
def dashboard(request):
    total = IrrigationPrediction.objects.count()
    method_counts = IrrigationPrediction.objects.values('result').annotate(count=Count('result'))
    most_used = None
    if method_counts:
        most_used = max(method_counts, key=lambda x: x['count'])['result']
    recent = IrrigationPrediction.objects.all().order_by('-created_at')[:5]

    return render(request, 'dashboard/dashboard.html', {
        'total': total,
        'most_used': most_used,
        'recent': recent,
        'method_counts': method_counts,
    })


# ── Predict ───────────────────────────────────────────────────────────────────
@login_required
def predict(request):
    if request.method == 'POST':
        soil  = request.POST.get('soil', '')
        crop  = request.POST.get('crop', '')
        water = request.POST.get('water', '')

        try:
            temp  = float(request.POST.get('temperature', 0))
            hum   = float(request.POST.get('humidity', 0))
            rain  = float(request.POST.get('rainfall', 0))
        except ValueError:
            return render(request, 'system/result.html', {'result': 'Invalid numeric input'})

        # Validation
        if not (0 <= temp <= 60):
            return render(request, 'system/result.html', {'result': 'Invalid Temperature (0–60°C)'})
        if not (0 <= hum <= 100):
            return render(request, 'system/result.html', {'result': 'Invalid Humidity (0–100%)'})
        if not (0 <= rain <= 500):
            return render(request, 'system/result.html', {'result': 'Invalid Rainfall (0–500mm)'})

        try:
            soil_enc  = le_soil.transform([soil])[0]
            crop_enc  = le_crop.transform([crop])[0]
            water_enc = le_water.transform([water])[0]

            prediction = model.predict([[soil_enc, crop_enc, temp, hum, rain, water_enc]])
            result = le_output.inverse_transform(prediction)[0]
        except Exception as e:
            return render(request, 'system/result.html', {'result': f'Prediction Error: {e}'})

        # Recommendation
        recommendations = {
            'Drip': (
                'Drip irrigation is best for conserving water and delivering it directly to plant roots.',
                'Use drip lines, irrigate early morning or evening, and monitor soil moisture regularly.'
            ),
            'Sprinkler': (
                'Sprinkler irrigation is suitable for uniform water distribution across the field.',
                'Avoid using during high winds. Best for medium rainfall and moderate water availability.'
            ),
            'Surface': (
                'Surface irrigation is effective when water availability is high and land is level.',
                'Ensure proper field leveling to avoid water loss and uneven distribution.'
            ),
        }
        recommendation, suggestion = recommendations.get(result, ('', ''))

        # Smart tips
        tips = []
        if temp > 35:
            tips.append('High temperature detected: Increase irrigation frequency.')
        if hum < 40:
            tips.append('Low humidity: Risk of evaporation loss is high.')
        if rain > 150:
            tips.append('High rainfall: Avoid over-irrigation.')
        if soil == 'Sandy':
            tips.append('Sandy soil: Water drains quickly, frequent irrigation needed.')
        if water == 'Low':
            tips.append('Low water availability: Prefer water-saving techniques like drip irrigation.')

        # Save to DB
        IrrigationPrediction.objects.create(
            soil_type=soil, crop_type=crop,
            temperature=temp, humidity=hum,
            rainfall=rain, water_availability=water,
            result=result
        )

        return render(request, 'system/result.html', {
            'result': result,
            'recommendation': recommendation,
            'suggestion': suggestion,
            'tips': tips,
        })

    return render(request, 'system/predict.html')


# ── History ───────────────────────────────────────────────────────────────────
def history(request):
    records = IrrigationPrediction.objects.all().order_by('-created_at')
    return render(request, 'system/history.html', {'records': records})
