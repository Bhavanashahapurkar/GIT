# modelapp/urls.py
from django.urls import path
from .views import predict, history

app_name = 'modelapp'

urlpatterns = [
    path('predict/', predict, name='predict'),
    path('history/', history, name='history'),
]
