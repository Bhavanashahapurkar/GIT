import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset
df = pd.read_csv("models/irrigation_dataset.csv")

# Encode categorical data
le_soil = LabelEncoder()
le_crop = LabelEncoder()
le_water = LabelEncoder()
le_output = LabelEncoder()

df['soil_type'] = le_soil.fit_transform(df['soil_type'])
df['crop_type'] = le_crop.fit_transform(df['crop_type'])
df['water_availability'] = le_water.fit_transform(df['water_availability'])
df['irrigation_method'] = le_output.fit_transform(df['irrigation_method'])

# Features & target
X = df.drop('irrigation_method', axis=1)
y = df['irrigation_method']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Model (Random Forest)
model = RandomForestClassifier(n_estimators=100)
model.fit(X_train, y_train)

# Save model
joblib.dump(model, "models/model.pkl")

# Save encoders
joblib.dump(le_soil, "models/le_soil.pkl")
joblib.dump(le_crop, "models/le_crop.pkl")
joblib.dump(le_water, "models/le_water.pkl")
joblib.dump(le_output, "models/le_output.pkl")

print("Model trained and saved!")