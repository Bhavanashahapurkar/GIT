import pandas as pd
import random

# Possible values
soil_types = ["Loamy", "Sandy", "Clay"]
crop_types = ["Rice", "Wheat", "Cotton", "Sugarcane", "Vegetables"]
water_levels = ["Low", "Medium", "High"]

def decide_irrigation(soil, crop, temp, humidity, rainfall, water):
    # Rule-based logic (acts like real-world knowledge)

    # High rainfall → Surface irrigation
    if rainfall > 150:
        return "Surface"

    # Low water → Drip irrigation
    if water == "Low":
        return "Drip"

    # Sandy soil loses water quickly → Drip
    if soil == "Sandy":
        return "Drip"

    # Moderate conditions → Sprinkler
    if 50 <= rainfall <= 150 and water == "Medium":
        return "Sprinkler"

    # High humidity crops (like rice) → Surface
    if crop == "Rice" and humidity > 70:
        return "Surface"

    # Default fallback
    return random.choice(["Drip", "Sprinkler", "Surface"])


# Generate dataset
data = []

for _ in range(50000):
    soil = random.choice(soil_types)
    crop = random.choice(crop_types)
    temp = round(random.uniform(20, 40), 1)         # °C
    humidity = random.randint(30, 90)               # %
    rainfall = random.randint(0, 250)               # mm
    water = random.choice(water_levels)

    irrigation = decide_irrigation(soil, crop, temp, humidity, rainfall, water)

    data.append([
        soil, crop, temp, humidity, rainfall, water, irrigation
    ])

# Create DataFrame
df = pd.DataFrame(data, columns=[
    "soil_type",
    "crop_type",
    "temperature",
    "humidity",
    "rainfall",
    "water_availability",
    "irrigation_method"
])

# Save CSV
df.to_csv("models/irrigation_dataset_50k.csv", index=False)

print("✅ Dataset with 50,000 rows generated successfully!")