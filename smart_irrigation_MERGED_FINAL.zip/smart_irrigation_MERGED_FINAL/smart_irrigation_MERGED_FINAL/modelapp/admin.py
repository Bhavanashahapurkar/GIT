from django.contrib import admin
from .models import IrrigationPrediction


@admin.register(IrrigationPrediction)
class IrrigationPredictionAdmin(admin.ModelAdmin):
    list_display = ('crop_type', 'soil_type', 'result', 'temperature', 'humidity', 'rainfall', 'created_at')
    list_filter = ('result', 'soil_type', 'crop_type')
    search_fields = ('crop_type', 'soil_type', 'result')
    ordering = ['-created_at']
